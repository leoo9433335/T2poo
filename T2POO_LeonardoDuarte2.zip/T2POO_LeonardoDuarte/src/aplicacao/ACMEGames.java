
package aplicacao;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.Scanner;
import java.io.FileReader;

import dados.*;



public class ACMEGames {

	private Scanner entrada;
	private final PrintStream saidaPadrao = System.out;
	private BufferedReader streamEntrada;
	private Ludoteca ludoteca;

	public ACMEGames() {
		try {
			streamEntrada = new BufferedReader(new FileReader("dadosin.txt"));
			entrada = new Scanner(streamEntrada);
			PrintStream streamSaida = new PrintStream(new File("dadosout.txt"), StandardCharsets.UTF_8);
			System.setOut(streamSaida);

			Locale.setDefault(Locale.ENGLISH);
			entrada.useLocale(Locale.ENGLISH);
			if (entrada != null) {
				entrada.useLocale(Locale.ENGLISH);

			} else {
				System.out.println("O objeto 'entrada' não foi inicializado corretamente.");
			}
		} catch (FileNotFoundException e) {
			System.out.println("Arquivo não encontrado: " + e.getMessage());
		} catch (Exception e) {
			System.out.println("Ocorreu um erro: " + e);
		}

		ludoteca = new Ludoteca();

	}


	public void executa() {
		Cadastra_jogo_eletronico();
		Cadastratra_jogo_tabuleiro();
		mostradertminadojogo();
		mostradeterminadojogodeano();
		mostradadosjogodseletrocin();
		Mostradadosjogotabuleiro();
		mostrasomatorio();
		Mostrapcbasejogo();
		tabuleiromaisantigo();


	}

	public void Cadastra_jogo_eletronico() {
		String linha = "";
		try {
			while ((linha = streamEntrada.readLine()) != null) {

				if (linha.equals("-1")) {
					break;
				}

				Scanner am = new Scanner(linha).useDelimiter(";");

				String nome = am.next();

				int ano = am.nextInt();

				double precoBase = am.nextDouble();


				String plataforma = am.next();

				Categoria categoria = Categoria.verificacateg(am.next());

				JogoEletronico KOP = new JogoEletronico(nome, ano, precoBase, plataforma, categoria);
				if (ludoteca.addJogo(KOP)) {
					System.out.println("1:" + KOP.getNome() + "," + KOP.getPrecoBase());
				} else {
					System.out.println("1:Erro-jogo repetido:" + KOP.getNome());
				}

			}
			;

		} catch (IOException e) {
			e.printStackTrace();


		}
	}

	public void Cadastratra_jogo_tabuleiro() {
		String linha = "";
		try {

			while ((linha = streamEntrada.readLine()) != null) {
				if (linha.equals("-1")) {
					break;
				}
				Scanner df = new Scanner(linha).useDelimiter(";");

				String nome = df.next();
				int ano = df.nextInt();
				double precoBase = df.nextDouble();
				int numeroPecas = df.nextInt();
				JogoTabuleiro LO = new JogoTabuleiro(nome, ano, precoBase, numeroPecas);
				if (ludoteca.addJogo(LO)) {

					System.out.println("2:NOME DO JOGO:" + LO.getNome() + ",PRECO FINAL:" + LO.calculaPrecoFinal());
				} else {
					System.out.println("2:Erro-jogo com nome repetido:" + LO.getNome());
				}
			}


		} catch (Exception e) {

		}

	}

	public void mostradertminadojogo() {
		try {
			String linha = "";


//				Scanner er =  new Scanner(linha).useDelimiter(";");
			String nome = streamEntrada.readLine();
			if (ludoteca.consultaPorNome(nome) == null) {
				System.out.println("3:Nome inexistente");
			}
			Jogo t = ludoteca.consultaPorNome(nome);

			System.out.println("3: NOME:" + t.getNome() + ",ANO:" + t.getAno() + ",PREÇO BASE:" + t.getPrecoBase() + ",PREÇO FINAL:" + t.calculaPrecoFinal());


		} catch (Exception e) {

		}


	}

	public void mostradeterminadojogodeano() {

		try {
			int ano = entrada.nextInt();
			entrada.nextLine();

			ArrayList<Jogo> jogosDoAno = ludoteca.consultaPorAno(ano);
			if (jogosDoAno.isEmpty()) {
				System.out.println("4:NENHUM JOGO ENCONTRADO");
			} else {

				for (Jogo jogoFor : jogosDoAno) {
					if (jogoFor instanceof JogoTabuleiro) {
						JogoTabuleiro ji = (JogoTabuleiro) jogoFor;
						System.out.println("4:NOME:" + ji.getNome() + ",ANO:" + ji.getAno() + ",PREÇO BASE:" + ji.getPrecoBase() + ",PREÇO FINAL" + ji.calculaPrecoFinal());
					}

				}
			}
		} catch (Exception e) {
			System.out.println("erro: " + e);
		}

	}


	public void mostradadosjogodseletrocin() {
		try {

			Categoria categoria = Categoria.verificacateg(streamEntrada.readLine());
			System.out.println("BSBCAB");
			ArrayList<Jogo> KOP = ludoteca.getJogos();
			List<JogoEletronico> jogoEletronicos = KOP
					.stream()
					.filter(jogo -> jogo instanceof JogoEletronico)
					.map(Jogo -> (JogoEletronico) Jogo)
					.toList();
			Categoria bnn = Categoria.verificacateg(

			for (JogoEletronico jogo : jogoEletronicos) {
				if (jogo.equals(Categoria.verificacateg()) {
					System.out.println("5:NOME"+jogo.getNome());
					streamEntrada.read();
				} else {
					System.out.println("5:JOGO NÃO ENCONTRADO");
				}
			}
		} catch(Exception e){

		 }

}



	public void mostrasomatorio() {
		try {


			double somatorio = 0;
			ArrayList<Jogo> jogos = ludoteca.getJogos();
			for (Jogo J : jogos) {
				somatorio += J.calculaPrecoFinal();

			}
			if (somatorio == 0) {
				System.out.println("6:NENHUM JOGO ENCONTRADO");
			} else {
				String inddh = String.format("%.Of", somatorio);
				System.out.println("6: VALOR DO SOMATORIO:" + somatorio);
			}

		} catch (Exception e) {

		}
	}


	public void Mostradadosjogotabuleiro() {
		try {


			JogoTabuleiro maior = null;
			ArrayList<Jogo> jogos = ludoteca.getJogos();
			Iterador IERATOR = (Iterador) jogos.iterator();

			while (IERATOR.hasNext()) {
				Jogo K = (Jogo) IERATOR.next();
				if (K instanceof JogoTabuleiro) {
					JogoTabuleiro KO = (JogoTabuleiro) K;
					if (KO.calculaPrecoFinal() > maior.calculaPrecoFinal()) {
						maior = KO;
					}
				}
			}
            if (maior.calculaPrecoFinal() != 0) {
                System.out.println("7: NOME:" + maior.getNome() + ",PREÇO FINAL:" + maior.calculaPrecoFinal());
            } else {
                System.out.println("7:NENHUM JOGO ENCONTRADO");
            }

        } catch (Exception e) {
		}


	}

	public void Mostrapcbasejogo() {

		try {


			ArrayList<Jogo> jogos = ludoteca.getJogos();
			if (jogos.isEmpty()) {
				System.out.println("8:NENHUM JOGO ENCONTRADO");
			} else {

				double cal = 0;
				for (Jogo J : jogos)
					cal += J.getPrecoBase();
				double media = cal / jogos.size();

				Jogo proxjogo = Collections.min(jogos, Comparator.comparingDouble(value -> Math.abs(value.getPrecoBase() - media)));
				System.out.println("8:media dos preços" + proxjogo.getNome() + ",ano:" + proxjogo.getAno() + ",preço" + proxjogo.getPrecoBase() + ",preço final" + proxjogo.calculaPrecoFinal());
			}

		} catch (Exception e) {

		}

	}

	public void tabuleiromaisantigo() {
		try {

			ArrayList<Jogo> jogos = ludoteca.getJogos();
			JogoTabuleiro antigo = null;
			List<JogoTabuleiro> jogoTabuleiros = jogos
					.stream()
					.filter(jogo -> jogo instanceof JogoTabuleiro)
					.map(Jogo -> (JogoTabuleiro) Jogo)
					.toList();

			if (jogoTabuleiros.isEmpty()) {
				System.out.println("9:NOME JOGO ENCONTRADO");
			} else {
				for (JogoTabuleiro JI : jogoTabuleiros) {
					if (JI.getAno() < antigo.getAno()) {
						antigo = JI;
					}
					System.out.println("9:NOME DO JOGO:" + antigo.getNome() + ",ANO:" + antigo.getAno());

				}

			}
		} catch (Exception e) {

		}

	}

}