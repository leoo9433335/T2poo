package dados;

public enum Categoria {

	ACT("Acao"),

	STR("Estrategia"),

	SIM("Simulacao");

	private String nome;


	public static Categoria verificacateg(String nome){


		if (nome.equalsIgnoreCase("Acao")){
			return ACT;
		}
		if(nome.equalsIgnoreCase("Estrategia")){
			return STR;
		}
		if (nome.equalsIgnoreCase("Simulação")){
			return SIM;
		}
		else {
			return null;
		}
	}


	private Categoria(String nome) {
     this.nome=nome;
	}



	public String getNome() {
		return nome;
	}


}
